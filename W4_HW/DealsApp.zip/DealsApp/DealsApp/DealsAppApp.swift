//
//  DealsAppApp.swift
//  DealsApp
//
//  Created by renupunjabi on 7/3/23.
//

import SwiftUI

@main
struct DealsAppApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
