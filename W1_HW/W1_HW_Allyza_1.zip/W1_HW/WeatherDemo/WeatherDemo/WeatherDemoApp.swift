//
//  WeatherDemoApp.swift
//  WeatherDemo
//
//  Created by allyza elnar on 6/10/23.
//

import SwiftUI

@main
struct WeatherDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
