import UIKit

func fib(_ n: Int) -> Int{
    if (n <= 1){
        return n
    }
    else{
        return fib(n-1) + fib(n-2)
    }
}

var result = fib(4)
print(result)
